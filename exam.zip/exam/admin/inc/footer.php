 </section>
<section class="footeroption">
		<h2><a href="https://sritechpro.com" style="color: aqua;"><?php echo "Shree Ganesh (SRI TECH)"; ?></a></h2><br>
		<img width="150px" height="95px" src="img\logo.png"/>
	</section>
</div>
</body>
</html>